$ErrorActionPreference = "Stop"

$schemeName = "Taiyaki Snack Cursors"
$cursorKey = "HKCU:\Control Panel\Cursors"
$schemeKey = Join-Path $cursorKey "Schemes"

$defaults = [ordered]@{
    "Arrow"       = ""
    "Help"        = ""
    "AppStarting" = ""
    "Wait"        = ""
    "Crosshair"   = ""
    "IBeam"       = ""
    "NWPen"       = ""
    "No"          = ""
    "SizeNS"      = ""
    "SizeWE"      = ""
    "SizeNWSE"    = ""
    "SizeNESW"    = ""
    "SizeAll"     = ""
    "UpArrow"     = ""
    "Hand"        = ""
    "Pin"         = ""
    "Person"      = ""
}

Set-ItemProperty -Path $cursorKey -Name "(default)" -Value ""
foreach ($entry in $defaults.GetEnumerator()) {
    Set-ItemProperty -Path $cursorKey -Name $entry.Key -Value $entry.Value
}

if (Test-Path $schemeKey) {
    Remove-ItemProperty -Path $schemeKey -Name $schemeName -ErrorAction SilentlyContinue
}

Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class CursorRefresh {
    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);
}
"@

$SPI_SETCURSORS = 0x0057
$SPIF_UPDATEINIFILE = 0x01
$SPIF_SENDCHANGE = 0x02
[CursorRefresh]::SystemParametersInfo($SPI_SETCURSORS, 0, $null, $SPIF_UPDATEINIFILE -bor $SPIF_SENDCHANGE) | Out-Null

Write-Host "Restored Windows default cursor settings for the current user."
Write-Host "Installed files were left in LocalAppData so you can reinstall without copying again."
