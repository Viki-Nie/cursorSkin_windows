$ErrorActionPreference = "Stop"

$schemeName = "Taiyaki Snack Cursors"
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$sourceDir = Join-Path $scriptRoot "cursor_assets\cursors"
$installDir = Join-Path $env:LOCALAPPDATA "Microsoft\Windows\Cursors\TaiyakiSnack"

if (-not (Test-Path $sourceDir)) {
    throw "Cursor source folder not found: $sourceDir"
}

New-Item -ItemType Directory -Force -Path $installDir | Out-Null
Copy-Item -Path (Join-Path $sourceDir "*.*") -Destination $installDir -Force

$cursorMap = [ordered]@{
    "Arrow"       = "normal_select.cur"
    "Help"        = "help_select.cur"
    "AppStarting" = "working_in_background.ani"
    "Wait"        = "busy.ani"
    "Crosshair"   = "precision_select.cur"
    "IBeam"       = "text_select.cur"
    "NWPen"       = "normal_select.cur"
    "No"          = "unavailable.cur"
    "SizeNS"      = "vertical_resize.cur"
    "SizeWE"      = "horizontal_resize.cur"
    "SizeNWSE"    = "diagonal_resize_nwse.cur"
    "SizeNESW"    = "diagonal_resize_nesw.cur"
    "SizeAll"     = "move.cur"
    "UpArrow"     = "normal_select.cur"
    "Hand"        = "link_select.cur"
    "Pin"         = "location_select.cur"
    "Person"      = "person_select.cur"
}

$cursorKey = "HKCU:\Control Panel\Cursors"
Set-ItemProperty -Path $cursorKey -Name "(default)" -Value $schemeName

foreach ($entry in $cursorMap.GetEnumerator()) {
    $filePath = Join-Path $installDir $entry.Value
    if (-not (Test-Path $filePath)) {
        throw "Missing cursor file: $filePath"
    }
    Set-ItemProperty -Path $cursorKey -Name $entry.Key -Value $filePath
}

# Save the scheme so it appears in Mouse Properties > Pointers.
$schemeValue = ($cursorMap.Values | ForEach-Object { Join-Path $installDir $_ }) -join ","
$schemeKey = Join-Path $cursorKey "Schemes"
New-Item -Path $schemeKey -Force | Out-Null
Set-ItemProperty -Path $schemeKey -Name $schemeName -Value $schemeValue

Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class CursorRefresh {
    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);
}
"@

$SPI_SETCURSORS = 0x0057
$SPIF_UPDATEINIFILE = 0x01
$SPIF_SENDCHANGE = 0x02
[CursorRefresh]::SystemParametersInfo($SPI_SETCURSORS, 0, $null, $SPIF_UPDATEINIFILE -bor $SPIF_SENDCHANGE) | Out-Null

Write-Host "Installed cursor scheme: $schemeName"
Write-Host "Files copied to: $installDir"
Write-Host "If a few apps do not update immediately, sign out and back in or restart those apps."
