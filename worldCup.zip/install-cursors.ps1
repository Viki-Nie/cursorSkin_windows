$ErrorActionPreference = "Stop"

$SchemeName = "World Cup Cursors"
$InstallFolderName = "WorldCupCursors"

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$SourceDir = Join-Path $Root "cursor_assets\cursors"
$InstallDir = Join-Path $env:LOCALAPPDATA "Microsoft\Windows\Cursors\$InstallFolderName"
$CursorRegPath = "HKCU:\Control Panel\Cursors"
$SchemeRegPath = "HKCU:\Control Panel\Cursors\Schemes"

$CursorMap = [ordered]@{
    Arrow       = "normal_select.ani"
    Help        = "help_select.cur"
    AppStarting = "working_in_background.ani"
    Wait        = "busy.ani"
    Crosshair   = "precision_select.cur"
    IBeam       = "text_select.ani"
    NWPen       = "normal_select.ani"
    No          = "unavailable.cur"
    SizeNS      = "vertical_resize.cur"
    SizeWE      = "horizontal_resize.cur"
    SizeNWSE    = "diagonal_resize_nwse.cur"
    SizeNESW    = "diagonal_resize_nesw.cur"
    SizeAll     = "move.cur"
    UpArrow     = "normal_select.ani"
    Hand        = "link_select.cur"
    Pin         = "location_select.cur"
    Person      = "person_select.cur"
}

function Invoke-CursorRefresh {
    $signature = @"
using System;
using System.Runtime.InteropServices;

public static class CursorNativeMethods {
    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool SystemParametersInfo(int uiAction, int uiParam, string pvParam, int fWinIni);
}
"@
    if (-not ("CursorNativeMethods" -as [type])) {
        Add-Type -TypeDefinition $signature | Out-Null
    }

    $SPI_SETCURSORS = 0x0057
    $SPIF_UPDATEINIFILE = 0x01
    $SPIF_SENDCHANGE = 0x02
    [CursorNativeMethods]::SystemParametersInfo($SPI_SETCURSORS, 0, $null, ($SPIF_UPDATEINIFILE -bor $SPIF_SENDCHANGE)) | Out-Null
}

function Get-InstalledCursorPath($fileName) {
    return (Join-Path $InstallDir $fileName)
}

if (-not (Test-Path -LiteralPath $SourceDir)) {
    throw "Cursor source directory not found: $SourceDir"
}

$requiredFiles = $CursorMap.Values | Select-Object -Unique
foreach ($file in $requiredFiles) {
    $path = Join-Path $SourceDir $file
    if (-not (Test-Path -LiteralPath $path)) {
        throw "Missing cursor file: $path"
    }
}

New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
foreach ($file in $requiredFiles) {
    Copy-Item -LiteralPath (Join-Path $SourceDir $file) -Destination (Join-Path $InstallDir $file) -Force
}

New-Item -Path $SchemeRegPath -Force | Out-Null

foreach ($entry in $CursorMap.GetEnumerator()) {
    Set-ItemProperty -Path $CursorRegPath -Name $entry.Key -Value (Get-InstalledCursorPath $entry.Value)
}

$schemeOrder = @(
    "Arrow", "Help", "AppStarting", "Wait", "Crosshair", "IBeam", "NWPen", "No",
    "SizeNS", "SizeWE", "SizeNWSE", "SizeNESW", "SizeAll", "UpArrow", "Hand", "Pin", "Person"
)
$schemeValue = ($schemeOrder | ForEach-Object { Get-InstalledCursorPath $CursorMap[$_] }) -join ","
New-ItemProperty -Path $SchemeRegPath -Name $SchemeName -Value $schemeValue -PropertyType String -Force | Out-Null
Set-Item -Path $CursorRegPath -Value $SchemeName

Invoke-CursorRefresh

Write-Host "Installed cursor scheme: $SchemeName"
Write-Host "Cursor files copied to: $InstallDir"
Write-Host "If the cursor does not update immediately, sign out and sign back in."
