$ErrorActionPreference = "Stop"

$SchemeName = "World Cup Cursors"
$InstallFolderName = "WorldCupCursors"

$InstallDir = Join-Path $env:LOCALAPPDATA "Microsoft\Windows\Cursors\$InstallFolderName"
$CursorRegPath = "HKCU:\Control Panel\Cursors"
$SchemeRegPath = "HKCU:\Control Panel\Cursors\Schemes"
$WindowsCursorDir = Join-Path $env:WINDIR "Cursors"

function Invoke-CursorRefresh {
    $signature = @"
using System;
using System.Runtime.InteropServices;

public static class CursorNativeMethods {
    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool SystemParametersInfo(int uiAction, int uiParam, string pvParam, int fWinIni);
}
"@
    if (-not ("CursorNativeMethods" -as [type])) {
        Add-Type -TypeDefinition $signature | Out-Null
    }

    $SPI_SETCURSORS = 0x0057
    $SPIF_UPDATEINIFILE = 0x01
    $SPIF_SENDCHANGE = 0x02
    [CursorNativeMethods]::SystemParametersInfo($SPI_SETCURSORS, 0, $null, ($SPIF_UPDATEINIFILE -bor $SPIF_SENDCHANGE)) | Out-Null
}

function Get-SystemCursorOrBlank($fileName) {
    $path = Join-Path $WindowsCursorDir $fileName
    if (Test-Path -LiteralPath $path) {
        return $path
    }
    return ""
}

$DefaultCursorMap = [ordered]@{
    Arrow       = Get-SystemCursorOrBlank "aero_arrow.cur"
    Help        = Get-SystemCursorOrBlank "aero_helpsel.cur"
    AppStarting = Get-SystemCursorOrBlank "aero_working.ani"
    Wait        = Get-SystemCursorOrBlank "aero_busy.ani"
    Crosshair   = ""
    IBeam       = ""
    NWPen       = Get-SystemCursorOrBlank "aero_pen.cur"
    No          = Get-SystemCursorOrBlank "aero_unavail.cur"
    SizeNS      = Get-SystemCursorOrBlank "aero_ns.cur"
    SizeWE      = Get-SystemCursorOrBlank "aero_ew.cur"
    SizeNWSE    = Get-SystemCursorOrBlank "aero_nwse.cur"
    SizeNESW    = Get-SystemCursorOrBlank "aero_nesw.cur"
    SizeAll     = Get-SystemCursorOrBlank "aero_move.cur"
    UpArrow     = Get-SystemCursorOrBlank "aero_up.cur"
    Hand        = Get-SystemCursorOrBlank "aero_link.cur"
    Pin         = Get-SystemCursorOrBlank "aero_pin.cur"
    Person      = Get-SystemCursorOrBlank "aero_person.cur"
}

foreach ($entry in $DefaultCursorMap.GetEnumerator()) {
    Set-ItemProperty -Path $CursorRegPath -Name $entry.Key -Value $entry.Value
}

Set-Item -Path $CursorRegPath -Value "Windows Default"

if (Test-Path -Path $SchemeRegPath) {
    Remove-ItemProperty -Path $SchemeRegPath -Name $SchemeName -ErrorAction SilentlyContinue
}

if (Test-Path -LiteralPath $InstallDir) {
    Remove-Item -LiteralPath $InstallDir -Recurse -Force
}

Invoke-CursorRefresh

Write-Host "Removed cursor scheme: $SchemeName"
Write-Host "Restored Windows default cursor mapping."
Write-Host "If the cursor does not update immediately, sign out and sign back in."
